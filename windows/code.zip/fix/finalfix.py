#!/usr/bin/env python3
"""
Windows Security Final Fix Script
Fixes the last remaining non-compliant items
"""

import subprocess
import os
import platform
import ctypes
import sys
import time
import winreg

class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    END = '\033[0m'

def print_banner():
    print()
    print("WINDOWS SECURITY FINAL FIX SCRIPT")
    print(f"{Colors.BLUE}=" * 60 + f"{Colors.END}")
    print("Fixes the last 3 remaining non-compliant items")

def is_admin():
    """Check if running as administrator"""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def check_windows_os():
    """Verify the script is running on Windows"""
    if platform.system() != "Windows":
        print(f"{Colors.RED}[ERROR]{Colors.END} This script can only run on Windows operating systems.")
        sys.exit(1)

def fix_password_complexity():
    """Fix password complexity using multiple methods"""
    print(f"\n{Colors.BOLD}FIXING PASSWORD COMPLEXITY{Colors.END}")
    print("-" * 50)
    
    methods_tried = 0
    success = False
    
    # Method 1: Direct registry modification
    print(f"{Colors.YELLOW}[METHOD 1]{Colors.END} Direct registry modification...")
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Lsa", 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, "PasswordComplexity", 0, winreg.REG_DWORD, 1)
        print(f"{Colors.GREEN}[SUCCESS]{Colors.END} Registry method applied")
        methods_tried += 1
    except Exception as e:
        print(f"{Colors.RED}[FAILED]{Colors.END} Registry method failed: {e}")
    
    # Method 2: secedit with specific template
    print(f"{Colors.YELLOW}[METHOD 2]{Colors.END} secedit template method...")
    try:
        import tempfile
        template_content = """[Unicode]
Unicode=yes

[System Access]
PasswordComplexity = 1

[Version]
signature="$CHICAGO$"
Revision=1
"""
        temp_file = os.path.join(tempfile.gettempdir(), "complexity_fix.inf")
        with open(temp_file, 'w', encoding='utf-16') as f:
            f.write(template_content)
        
        result = subprocess.run([
            "secedit", "/configure", "/cfg", temp_file, "/areas", "SECURITYPOLICY"
        ], capture_output=True, text=True, timeout=30)
        
        os.remove(temp_file)
        
        if result.returncode == 0:
            print(f"{Colors.GREEN}[SUCCESS]{Colors.END} secedit method applied")
            success = True
        else:
            print(f"{Colors.RED}[FAILED]{Colors.END} secedit method failed")
        methods_tried += 1
    except Exception as e:
        print(f"{Colors.RED}[FAILED]{Colors.END} secedit method failed: {e}")
    
    # Method 3: PowerShell Group Policy
    print(f"{Colors.YELLOW}[METHOD 3]{Colors.END} PowerShell Group Policy method...")
    try:
        result = subprocess.run([
            "powershell", "-Command",
            "$policy = Get-Item 'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Lsa'; " +
            "Set-ItemProperty -Path 'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Lsa' -Name 'PasswordComplexity' -Value 1 -Type DWord; " +
            "gpupdate /force"
        ], capture_output=True, text=True, timeout=60)
        
        if result.returncode == 0:
            print(f"{Colors.GREEN}[SUCCESS]{Colors.END} PowerShell method applied")
            success = True
        else:
            print(f"{Colors.RED}[FAILED]{Colors.END} PowerShell method failed")
        methods_tried += 1
    except Exception as e:
        print(f"{Colors.RED}[FAILED]{Colors.END} PowerShell method failed: {e}")
    
    print(f"\n{Colors.BLUE}[SUMMARY]{Colors.END} Password Complexity: {methods_tried} methods tried")
    return success

def fix_user_rights():
    """Fix the two non-compliant user rights"""
    print(f"\n{Colors.BOLD}FIXING USER RIGHTS ASSIGNMENTS{Colors.END}")
    print("-" * 50)
    
    success_count = 0
    
    # Fix 1: Access this computer from the network
    print(f"{Colors.YELLOW}[FIXING]{Colors.END} Access this computer from the network...")
    try:
        result = subprocess.run([
            "powershell", "-Command",
            "$secpol = [System.IO.Path]::GetTempFileName(); " +
            "secedit /export /cfg $secpol; " +
            "(Get-Content $secpol) -replace '^SeNetworkLogonRight.*', 'SeNetworkLogonRight = *S-1-5-32-544,*S-1-5-32-555' | Set-Content $secpol; " +
            "secedit /configure /cfg $secpol /areas USER_RIGHTS; " +
            "Remove-Item $secpol"
        ], capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            print(f"{Colors.GREEN}[FIXED]{Colors.END} Network logon right set to Administrators, Remote Desktop Users")
            success_count += 1
        else:
            print(f"{Colors.RED}[FAILED]{Colors.END} Could not fix network logon right")
    except Exception as e:
        print(f"{Colors.RED}[FAILED]{Colors.END} Error fixing network logon right: {e}")
    
    # Fix 2: Allow log on locally (remove Guest)
    print(f"{Colors.YELLOW}[FIXING]{Colors.END} Allow log on locally...")
    try:
        result = subprocess.run([
            "powershell", "-Command",
            "$secpol = [System.IO.Path]::GetTempFileName(); " +
            "secedit /export /cfg $secpol; " +
            "(Get-Content $secpol) -replace '^SeInteractiveLogonRight.*', 'SeInteractiveLogonRight = *S-1-5-32-544,*S-1-5-32-545' | Set-Content $secpol; " +
            "secedit /configure /cfg $secpol /areas USER_RIGHTS; " +
            "Remove-Item $secpol"
        ], capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            print(f"{Colors.GREEN}[FIXED]{Colors.END} Interactive logon right set to Administrators, Users only")
            success_count += 1
        else:
            print(f"{Colors.RED}[FAILED]{Colors.END} Could not fix interactive logon right")
    except Exception as e:
        print(f"{Colors.RED}[FAILED]{Colors.END} Error fixing interactive logon right: {e}")
    
    print(f"\n{Colors.BLUE}[SUMMARY]{Colors.END} User Rights: {success_count}/2 fixed")
    return success_count == 2

def main():
    """Main function"""
    print_banner()
    check_windows_os()
    
    if not is_admin():
        print(f"{Colors.RED}[ERROR]{Colors.END} Administrator privileges required")
        print("Please run this script as Administrator.")
        input("\nPress Enter to exit...")
        sys.exit(1)
    
    print(f"{Colors.GREEN}[SUCCESS]{Colors.END} Running with Administrator privileges\n")
    
    print(f"{Colors.YELLOW}[INFO]{Colors.END} This script will fix the final 3 non-compliant items:")
    print("  • Password complexity requirements")
    print("  • Access this computer from the network (remove Users)")
    print("  • Allow log on locally (remove Guest)")
    print()
    
    confirm = input(f"{Colors.BLUE}[CONFIRM]{Colors.END} Do you want to proceed? (y/N): ").strip().lower()
    if confirm not in ['y', 'yes']:
        print(f"{Colors.YELLOW}[CANCELLED]{Colors.END} Operation cancelled by user")
        sys.exit(0)
    
    try:
        # Fix password complexity
        password_success = fix_password_complexity()
        
        # Fix user rights
        rights_success = fix_user_rights()
        
        # Force Group Policy update
        print(f"\n{Colors.YELLOW}[WORKING]{Colors.END} Updating Group Policy...")
        try:
            subprocess.run(["gpupdate", "/force"], capture_output=True, timeout=60)
            print(f"{Colors.GREEN}[SUCCESS]{Colors.END} Group Policy updated")
        except:
            print(f"{Colors.YELLOW}[WARNING]{Colors.END} Group Policy update may have failed")
        
        # Summary
        print(f"\n{Colors.BOLD}FINAL SUMMARY{Colors.END}")
        print("=" * 60)
        
        total_fixes = 3
        fixes_applied = 0
        
        if password_success:
            fixes_applied += 1
            print(f"{Colors.GREEN}[FIXED]{Colors.END} Password complexity requirements")
        else:
            print(f"{Colors.RED}[FAILED]{Colors.END} Password complexity requirements")
        
        if rights_success:
            fixes_applied += 2
            print(f"{Colors.GREEN}[FIXED]{Colors.END} User rights assignments")
        else:
            print(f"{Colors.RED}[FAILED]{Colors.END} User rights assignments")
        
        print(f"\n{Colors.BLUE}[RESULT]{Colors.END} {fixes_applied}/{total_fixes} issues fixed")
        
        if fixes_applied == total_fixes:
            print(f"\n{Colors.GREEN}[COMPLETE]{Colors.END} All remaining issues have been fixed!")
            print("Your Windows system should now be 100% compliant.")
        elif fixes_applied > 0:
            print(f"\n{Colors.YELLOW}[PARTIAL]{Colors.END} Some fixes were applied.")
            print("You may need to restart and run the checkers again.")
        else:
            print(f"\n{Colors.RED}[FAILED]{Colors.END} No fixes could be applied.")
            print("Manual configuration may be required.")
        
        print(f"\n{Colors.BLUE}[RECOMMENDATION]{Colors.END}")
        print("1. Restart your computer")
        print("2. Run the checker scripts to verify 100% compliance")
        print("3. Your system security is already excellent!")
        
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}[CANCELLED]{Colors.END} Operation interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n{Colors.RED}[ERROR]{Colors.END} Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()