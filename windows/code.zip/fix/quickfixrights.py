#!/usr/bin/env python3
"""
Windows User Rights Quick Fix Script
Fixes the 2 remaining non-compliant user rights assignments
"""

import subprocess
import os
import platform
import ctypes
import sys
import time

class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    END = '\033[0m'

def print_banner():
    print()
    print("WINDOWS USER RIGHTS QUICK FIX")
    print(f"{Colors.BLUE}=" * 50 + f"{Colors.END}")
    print("Fixes network access and local logon rights")

def is_admin():
    """Check if running as administrator"""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def check_windows_os():
    """Verify the script is running on Windows"""
    if platform.system() != "Windows":
        print(f"{Colors.RED}[ERROR]{Colors.END} This script can only run on Windows operating systems.")
        sys.exit(1)

def fix_network_logon_right():
    """Fix 'Access this computer from the network' - remove Users, keep only Administrators and Remote Desktop Users"""
    print(f"{Colors.YELLOW}[FIXING]{Colors.END} Access this computer from the network...")
    
    try:
        # Method 1: PowerShell with secedit
        result = subprocess.run([
            "powershell", "-Command",
            "$secpol = [System.IO.Path]::GetTempFileName(); " +
            "secedit /export /cfg $secpol /quiet; " +
            "(Get-Content $secpol) -replace '^SeNetworkLogonRight.*', 'SeNetworkLogonRight = *S-1-5-32-544,*S-1-5-32-555' | Set-Content $secpol; " +
            "secedit /configure /cfg $secpol /areas USER_RIGHTS /quiet; " +
            "Remove-Item $secpol -ErrorAction SilentlyContinue"
        ], capture_output=True, text=True, timeout=60)
        
        if result.returncode == 0:
            print(f"{Colors.GREEN}[FIXED]{Colors.END} Network access restricted to Administrators and Remote Desktop Users")
            return True
        else:
            print(f"{Colors.RED}[FAILED]{Colors.END} PowerShell method failed")
            
        # Method 2: Direct secedit template
        import tempfile
        template_content = """[Unicode]
Unicode=yes

[Privilege Rights]
SeNetworkLogonRight = *S-1-5-32-544,*S-1-5-32-555

[Version]
signature="$CHICAGO$"
Revision=1
"""
        
        temp_file = os.path.join(tempfile.gettempdir(), "network_fix.inf")
        with open(temp_file, 'w', encoding='utf-16') as f:
            f.write(template_content)
        
        result2 = subprocess.run([
            "secedit", "/configure", "/cfg", temp_file, "/areas", "USER_RIGHTS"
        ], capture_output=True, text=True, timeout=30)
        
        os.remove(temp_file)
        
        if result2.returncode == 0:
            print(f"{Colors.GREEN}[FIXED]{Colors.END} Network access fixed via secedit template")
            return True
        else:
            print(f"{Colors.RED}[FAILED]{Colors.END} Template method also failed")
            return False
            
    except Exception as e:
        print(f"{Colors.RED}[ERROR]{Colors.END} Error fixing network logon right: {e}")
        return False

def fix_interactive_logon_right():
    """Fix 'Allow log on locally' - remove Guest, keep only Administrators and Users"""
    print(f"{Colors.YELLOW}[FIXING]{Colors.END} Allow log on locally...")
    
    try:
        # Method 1: PowerShell with secedit
        result = subprocess.run([
            "powershell", "-Command",
            "$secpol = [System.IO.Path]::GetTempFileName(); " +
            "secedit /export /cfg $secpol /quiet; " +
            "(Get-Content $secpol) -replace '^SeInteractiveLogonRight.*', 'SeInteractiveLogonRight = *S-1-5-32-544,*S-1-5-32-545' | Set-Content $secpol; " +
            "secedit /configure /cfg $secpol /areas USER_RIGHTS /quiet; " +
            "Remove-Item $secpol -ErrorAction SilentlyContinue"
        ], capture_output=True, text=True, timeout=60)
        
        if result.returncode == 0:
            print(f"{Colors.GREEN}[FIXED]{Colors.END} Local logon restricted to Administrators and Users (Guest removed)")
            return True
        else:
            print(f"{Colors.RED}[FAILED]{Colors.END} PowerShell method failed")
            
        # Method 2: Direct secedit template
        import tempfile
        template_content = """[Unicode]
Unicode=yes

[Privilege Rights]
SeInteractiveLogonRight = *S-1-5-32-544,*S-1-5-32-545

[Version]
signature="$CHICAGO$"
Revision=1
"""
        
        temp_file = os.path.join(tempfile.gettempdir(), "interactive_fix.inf")
        with open(temp_file, 'w', encoding='utf-16') as f:
            f.write(template_content)
        
        result2 = subprocess.run([
            "secedit", "/configure", "/cfg", temp_file, "/areas", "USER_RIGHTS"
        ], capture_output=True, text=True, timeout=30)
        
        os.remove(temp_file)
        
        if result2.returncode == 0:
            print(f"{Colors.GREEN}[FIXED]{Colors.END} Interactive logon fixed via secedit template")
            return True
        else:
            print(f"{Colors.RED}[FAILED]{Colors.END} Template method also failed")
            return False
            
    except Exception as e:
        print(f"{Colors.RED}[ERROR]{Colors.END} Error fixing interactive logon right: {e}")
        return False

def main():
    """Main function"""
    print_banner()
    check_windows_os()
    
    if not is_admin():
        print(f"{Colors.RED}[ERROR]{Colors.END} Administrator privileges required")
        print("Please run this script as Administrator.")
        input("\nPress Enter to exit...")
        sys.exit(1)
    
    print(f"{Colors.GREEN}[SUCCESS]{Colors.END} Running with Administrator privileges\n")
    
    print(f"{Colors.YELLOW}[SECURITY ALERT]{Colors.END} Fixing critical user rights vulnerabilities:")
    print("  • Remove 'Users' from network access (security risk)")
    print("  • Remove 'Guest' from local logon (security risk)")
    print()
    
    confirm = input(f"{Colors.BLUE}[CONFIRM]{Colors.END} Fix these security issues? (y/N): ").strip().lower()
    if confirm not in ['y', 'yes']:
        print(f"{Colors.YELLOW}[CANCELLED]{Colors.END} Operation cancelled by user")
        sys.exit(0)
    
    print()
    
    try:
        # Fix both user rights
        network_success = fix_network_logon_right()
        time.sleep(2)
        interactive_success = fix_interactive_logon_right()
        
        # Force Group Policy update
        print(f"\n{Colors.YELLOW}[WORKING]{Colors.END} Updating Group Policy...")
        try:
            subprocess.run(["gpupdate", "/force"], capture_output=True, timeout=60)
            print(f"{Colors.GREEN}[SUCCESS]{Colors.END} Group Policy updated")
        except:
            print(f"{Colors.YELLOW}[WARNING]{Colors.END} Group Policy update may have failed")
        
        # Summary
        print(f"\n{Colors.BOLD}SECURITY FIX SUMMARY{Colors.END}")
        print("=" * 50)
        
        fixes_applied = 0
        if network_success:
            fixes_applied += 1
            print(f"{Colors.GREEN}[SECURED]{Colors.END} Network access rights")
        else:
            print(f"{Colors.RED}[FAILED]{Colors.END} Network access rights")
        
        if interactive_success:
            fixes_applied += 1
            print(f"{Colors.GREEN}[SECURED]{Colors.END} Local logon rights")
        else:
            print(f"{Colors.RED}[FAILED]{Colors.END} Local logon rights")
        
        print(f"\n{Colors.BLUE}[RESULT]{Colors.END} {fixes_applied}/2 security vulnerabilities fixed")
        
        if fixes_applied == 2:
            print(f"\n{Colors.GREEN}[COMPLETE]{Colors.END} Critical security vulnerabilities resolved!")
            print("Your system is now properly secured.")
        elif fixes_applied == 1:
            print(f"\n{Colors.YELLOW}[PARTIAL]{Colors.END} Some security issues remain.")
            print("Manual configuration may be required.")
        else:
            print(f"\n{Colors.RED}[FAILED]{Colors.END} Security vulnerabilities remain.")
            print("Manual intervention required via secpol.msc")
        
        print(f"\n{Colors.BLUE}[NEXT STEPS]{Colors.END}")
        print("1. Restart your computer")
        print("2. Run the local policies checker to verify")
        print("3. Test system functionality")
        
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}[CANCELLED]{Colors.END} Operation interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n{Colors.RED}[ERROR]{Colors.END} Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()