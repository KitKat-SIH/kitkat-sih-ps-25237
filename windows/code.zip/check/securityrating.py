#!/usr/bin/env python3
"""
Windows Security Compliance Rating System
Analyzes all security checks and provides overall system rating
"""

import subprocess
import sys
import platform
import time
import os

class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    END = '\033[0m'

def print_banner():
    print()
    print(f"{Colors.CYAN}{Colors.BOLD}WINDOWS SECURITY COMPLIANCE ANALYZER{Colors.END}")
    print(f"{Colors.BLUE}=" * 60 + f"{Colors.END}")
    print("Comprehensive security assessment and rating")

def check_windows_os():
    """Verify the script is running on Windows"""
    if platform.system() != "Windows":
        print(f"{Colors.RED}[ERROR]{Colors.END} This script can only run on Windows operating systems.")
        sys.exit(1)

def run_security_check(script_name, category_name):
    """Run a security check script and capture results"""
    print(f"{Colors.YELLOW}[ANALYZING]{Colors.END} {category_name}...")
    
    try:
        # Change to check directory
        check_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'check')
        script_path = os.path.join(check_dir, script_name)
        
        if not os.path.exists(script_path):
            print(f"{Colors.RED}[ERROR]{Colors.END} Script not found: {script_path}")
            return None
        
        result = subprocess.run(
            [sys.executable, script_path],
            capture_output=True,
            text=True,
            timeout=120,
            cwd=check_dir
        )
        
        if result.returncode == 0:
            return result.stdout
        else:
            print(f"{Colors.RED}[ERROR]{Colors.END} Failed to run {script_name}")
            return None
            
    except subprocess.TimeoutExpired:
        print(f"{Colors.RED}[TIMEOUT]{Colors.END} {script_name} took too long")
        return None
    except Exception as e:
        print(f"{Colors.RED}[ERROR]{Colors.END} Error running {script_name}: {e}")
        return None

def analyze_output(output, category_name):
    """Analyze the output from a security check script"""
    if not output:
        return {"compliant": 0, "total": 0, "percentage": 0, "status": "ERROR"}
    
    lines = output.split('\n')
    compliant_count = 0
    non_compliant_count = 0
    manual_check_count = 0
    
    for line in lines:
        line = line.strip()
        if '[COMPLIANT]' in line or '[ASSUMED COMPLIANT]' in line:
            compliant_count += 1
        elif '[NON-COMPLIANT]' in line or '[NOT FOUND]' in line:
            non_compliant_count += 1
        elif '[MANUAL CHECK' in line:
            manual_check_count += 1
    
    total_automated = compliant_count + non_compliant_count
    total_checks = total_automated + manual_check_count
    
    if total_automated > 0:
        percentage = (compliant_count / total_automated) * 100
    else:
        percentage = 0
    
    # Determine status
    if percentage >= 95:
        status = "EXCELLENT"
    elif percentage >= 85:
        status = "GOOD"
    elif percentage >= 70:
        status = "FAIR"
    elif percentage >= 50:
        status = "POOR"
    else:
        status = "CRITICAL"
    
    return {
        "compliant": compliant_count,
        "non_compliant": non_compliant_count,
        "manual_checks": manual_check_count,
        "total_automated": total_automated,
        "total_checks": total_checks,
        "percentage": percentage,
        "status": status
    }

def get_status_color(status):
    """Get color for status"""
    colors = {
        "EXCELLENT": Colors.GREEN,
        "GOOD": Colors.CYAN,
        "FAIR": Colors.YELLOW,
        "POOR": Colors.MAGENTA,
        "CRITICAL": Colors.RED,
        "ERROR": Colors.RED
    }
    return colors.get(status, Colors.WHITE)

def calculate_overall_rating(results):
    """Calculate overall security rating"""
    if not results:
        return "F", "CRITICAL"
    
    total_weighted_score = 0
    total_weight = 0
    
    # Weights for different categories (higher weight = more important)
    weights = {
        "Account Policies": 1.2,
        "Local Policies": 1.5,      # Higher weight - user rights are critical
        "Security Options": 1.3,
        "System Settings": 1.1,
        "Audit Policies": 1.0,
        "Defender Application Guard": 0.8
    }
    
    for category, data in results.items():
        if data["status"] != "ERROR":
            weight = weights.get(category, 1.0)
            total_weighted_score += data["percentage"] * weight
            total_weight += weight
    
    if total_weight == 0:
        overall_percentage = 0
    else:
        overall_percentage = total_weighted_score / total_weight
    
    # Letter grade system
    if overall_percentage >= 95:
        grade = "A+"
        rating = "ENTERPRISE GRADE"
    elif overall_percentage >= 90:
        grade = "A"
        rating = "EXCELLENT"
    elif overall_percentage >= 85:
        grade = "A-"
        rating = "VERY GOOD"
    elif overall_percentage >= 80:
        grade = "B+"
        rating = "GOOD"
    elif overall_percentage >= 75:
        grade = "B"
        rating = "ACCEPTABLE"
    elif overall_percentage >= 70:
        grade = "B-"
        rating = "FAIR"
    elif overall_percentage >= 65:
        grade = "C+"
        rating = "BELOW AVERAGE"
    elif overall_percentage >= 60:
        grade = "C"
        rating = "POOR"
    elif overall_percentage >= 50:
        grade = "D"
        rating = "CRITICAL"
    else:
        grade = "F"
        rating = "FAILING"
    
    return grade, rating, overall_percentage

def print_detailed_report(results):
    """Print detailed compliance report"""
    print(f"\n{Colors.BOLD}DETAILED COMPLIANCE REPORT{Colors.END}")
    print("=" * 60)
    
    for category, data in results.items():
        status_color = get_status_color(data["status"])
        
        print(f"\n{Colors.BOLD}{category}{Colors.END}")
        print("-" * len(category))
        
        if data["status"] == "ERROR":
            print(f"  Status: {Colors.RED}ERROR - Unable to analyze{Colors.END}")
            continue
        
        print(f"  Compliant: {Colors.GREEN}{data['compliant']}{Colors.END}")
        print(f"  Non-Compliant: {Colors.RED}{data['non_compliant']}{Colors.END}")
        if data['manual_checks'] > 0:
            print(f"  Manual Checks: {Colors.YELLOW}{data['manual_checks']}{Colors.END}")
        print(f"  Automated Score: {status_color}{data['percentage']:.1f}%{Colors.END}")
        print(f"  Rating: {status_color}{data['status']}{Colors.END}")

def print_recommendations(results, overall_grade, overall_rating):
    """Print security recommendations based on results"""
    print(f"\n{Colors.BOLD}SECURITY RECOMMENDATIONS{Colors.END}")
    print("=" * 60)
    
    critical_issues = []
    high_priority = []
    medium_priority = []
    
    for category, data in results.items():
        if data["status"] == "ERROR":
            critical_issues.append(f"Fix {category} analysis script")
        elif data["percentage"] < 70:
            critical_issues.append(f"Address {category} non-compliance ({data['non_compliant']} issues)")
        elif data["percentage"] < 85:
            high_priority.append(f"Improve {category} compliance ({data['non_compliant']} issues)")
        elif data["non_compliant"] > 0:
            medium_priority.append(f"Fine-tune {category} ({data['non_compliant']} minor issues)")
    
    if critical_issues:
        print(f"\n{Colors.RED}🚨 CRITICAL PRIORITY:{Colors.END}")
        for issue in critical_issues:
            print(f"  • {issue}")
    
    if high_priority:
        print(f"\n{Colors.YELLOW}⚠️  HIGH PRIORITY:{Colors.END}")
        for issue in high_priority:
            print(f"  • {issue}")
    
    if medium_priority:
        print(f"\n{Colors.BLUE}📋 MEDIUM PRIORITY:{Colors.END}")
        for issue in medium_priority:
            print(f"  • {issue}")
    
    if not critical_issues and not high_priority and not medium_priority:
        print(f"\n{Colors.GREEN}✅ EXCELLENT! No major issues found.{Colors.END}")
        print("Your system maintains strong security compliance.")

def main():
    """Main function"""
    print_banner()
    check_windows_os()
    
    # Security check scripts to run
    checks = [
        ("accountpolicies.py", "Account Policies"),
        ("localpolicies.py", "Local Policies"),
        ("securityoptions.py", "Security Options"),
        ("systemsettings.py", "System Settings"),
        ("auditpolicies.py", "Audit Policies"),
        ("defenderapplication.py", "Defender Application Guard")
    ]
    
    print(f"\n{Colors.BLUE}[INFO]{Colors.END} Running comprehensive security analysis...")
    print(f"This may take 2-3 minutes...\n")
    
    results = {}
    
    # Run all security checks
    for script, category in checks:
        output = run_security_check(script, category)
        results[category] = analyze_output(output, category)
        time.sleep(1)  # Brief pause between checks
    
    # Calculate overall rating
    overall_grade, overall_rating, overall_percentage = calculate_overall_rating(results)
    
    # Print results
    print_detailed_report(results)
    
    # Overall rating
    print(f"\n{Colors.BOLD}OVERALL SECURITY RATING{Colors.END}")
    print("=" * 60)
    
    grade_color = Colors.GREEN if overall_grade.startswith('A') else Colors.YELLOW if overall_grade.startswith('B') else Colors.RED
    
    print(f"\n{Colors.BOLD}Grade: {grade_color}{overall_grade}{Colors.END}")
    print(f"{Colors.BOLD}Rating: {grade_color}{overall_rating}{Colors.END}")
    print(f"{Colors.BOLD}Score: {grade_color}{overall_percentage:.1f}%{Colors.END}")
    
    # Security level indicator
    if overall_percentage >= 90:
        print(f"\n{Colors.GREEN}🛡️  ENTERPRISE SECURITY LEVEL{Colors.END}")
        print("Your system meets enterprise security standards!")
    elif overall_percentage >= 80:
        print(f"\n{Colors.CYAN}🔒 BUSINESS SECURITY LEVEL{Colors.END}")
        print("Good security posture with room for improvement.")
    elif overall_percentage >= 70:
        print(f"\n{Colors.YELLOW}⚠️  BASIC SECURITY LEVEL{Colors.END}")
        print("Minimum security requirements met.")
    else:
        print(f"\n{Colors.RED}🚨 INADEQUATE SECURITY LEVEL{Colors.END}")
        print("Immediate security improvements required!")
    
    # Recommendations
    print_recommendations(results, overall_grade, overall_rating)
    
    # Summary stats
    total_compliant = sum(r["compliant"] for r in results.values() if r["status"] != "ERROR")
    total_non_compliant = sum(r["non_compliant"] for r in results.values() if r["status"] != "ERROR")
    total_manual = sum(r["manual_checks"] for r in results.values() if r["status"] != "ERROR")
    
    print(f"\n{Colors.BOLD}SUMMARY STATISTICS{Colors.END}")
    print("=" * 60)
    print(f"Total Compliant Checks: {Colors.GREEN}{total_compliant}{Colors.END}")
    print(f"Total Non-Compliant: {Colors.RED}{total_non_compliant}{Colors.END}")
    print(f"Manual Verification Required: {Colors.YELLOW}{total_manual}{Colors.END}")
    print(f"Categories Analyzed: {len([r for r in results.values() if r['status'] != 'ERROR'])}/6")
    
    print(f"\n{Colors.BLUE}[COMPLETE]{Colors.END} Security analysis finished.")
    print(f"Report generated: {time.strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    main()