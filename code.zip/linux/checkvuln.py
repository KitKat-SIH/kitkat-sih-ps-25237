print("i am in LINUX ")

for i in range(500):
    print("NIGGER")