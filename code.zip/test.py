import platform
import subprocess

print(f"Operating System: {platform.system()}")
print(f"OS Release: {platform.release()}")
print(f"Machine Architecture: {platform.machine()}")
print(f"Python Version: {platform.python_version()}")
print(f"Full Platform Information: {platform.uname()}")


print(len("NON-COMPLIANT"))